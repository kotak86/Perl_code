package ManageFile;

use Exporter qw(import);
@EXPORT_OK = qw(CheckPermission ChangePermission);



