#!/usr/bin/perl

use strict;
use warnings;

print "The operating system is $^O";